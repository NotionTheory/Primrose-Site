python -m SimpleHTTPServer 8383 && xdg-open http://localhost:8383
