python -m SimpleHTTPServer 8383 && open http://localhost:8383
